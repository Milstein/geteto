// InterfDemo.java: ilustra o uso de uma interface

interface InterfaceExemplo
{
	void metodo1(int param);
}