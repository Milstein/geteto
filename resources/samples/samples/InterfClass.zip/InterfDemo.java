import java.util.*;
import java.io.*;
// import java.awt.*;
import java.lang.*;

class InterfDemo
{
	public static void main(String args[])
	{
		InterfClass IC = new InterfClass();
		IC.metodo1(10);
		IC.metodo2();
	}	
}