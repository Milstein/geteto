package GerReserva;

public interface IGerReserva
{

}
