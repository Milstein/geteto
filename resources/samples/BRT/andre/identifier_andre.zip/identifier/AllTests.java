package identifier;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTests {
	public static void main(String[] args) {
		junit.textui.TestRunner.run(TestIdentifier.class);
	}
}
